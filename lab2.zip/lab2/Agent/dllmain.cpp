#include "Detours/src/detours.h"

#include <stdio.h>
#include <tlhelp32.h>


#define MAX_PATH_OBJ 32767


struct PipeStruct
{
    HANDLE h_Pipe;

    OVERLAPPED* PipeOverlap;

    LPVOID PipeBuf;

    DWORD PipeBufSize;

    bool PipeMode;
};

struct DirName
{
    HANDLE h_File;

    char* DirNameA;

    wchar_t* DirNameW;
};

static HANDLE h_SemaphoreNotifier = NULL;

static HANDLE h_EventExit = NULL;

static HANDLE h_MutexSave = NULL;

static unsigned char EjectFlag = 2;

static wchar_t HideNameW[MAX_PATH_OBJ + 1] = { 0 };

static char HideNameA[MAX_PATH_OBJ + 1] = { 0 };

static struct DirName* SaveDirInfo = NULL;

static unsigned long long SaveLimit = 1024;

static unsigned long long SaveAmount = 0;

static HANDLE WINAPI MyCreateFileA(LPCSTR lpFileName, DWORD dwDesiredAccess, DWORD dwShareMode, LPSECURITY_ATTRIBUTES lpSecurityAttributes, DWORD dwCreationDisposition, DWORD dwFlagsAndAttributes, HANDLE hTemplateFile);

static HANDLE WINAPI MyCreateFileW(LPCWSTR lpFileName, DWORD dwDesiredAccess, DWORD dwShareMode, LPSECURITY_ATTRIBUTES lpSecurityAttributes, DWORD dwCreationDisposition, DWORD dwFlagsAndAttributes, HANDLE hTemplateFile);

static HANDLE WINAPI MyCreateFile2(LPCWSTR lpFileName, DWORD dwDesiredAccess, DWORD dwShareMode, DWORD dwCreationDisposition, LPCREATEFILE2_EXTENDED_PARAMETERS pCreateExParams);

static HANDLE WINAPI MyCreateFileTransactedA(LPCSTR lpFileName, DWORD dwDesiredAccess, DWORD dwShareMode, LPSECURITY_ATTRIBUTES lpSecurityAttributes, DWORD dwCreationDisposition, DWORD dwFlagsAndAttributes, HANDLE hTemplateFile, HANDLE hTransaction, PUSHORT pusMiniVersion, PVOID lpExtendedParameter);

static HANDLE WINAPI MyCreateFileTransactedW(LPCWSTR lpFileName, DWORD dwDesiredAccess, DWORD dwShareMode, LPSECURITY_ATTRIBUTES lpSecurityAttributes, DWORD dwCreationDisposition, DWORD dwFlagsAndAttributes, HANDLE hTemplateFile, HANDLE hTransaction, PUSHORT pusMiniVersion, PVOID lpExtendedParameter);

static HANDLE WINAPI MyFindFirstFileA(LPCSTR lpFileName, LPWIN32_FIND_DATAA lpFindFileData);

static HANDLE WINAPI MyFindFirstFileW(LPCWSTR lpFileName, LPWIN32_FIND_DATAW lpFindFileData);

static HANDLE WINAPI MyFindFirstFileExA(LPCSTR lpFileName, FINDEX_INFO_LEVELS fInfoLevelId, LPVOID lpFindFileData, FINDEX_SEARCH_OPS fSearchOp, LPVOID lpSearchFilter, DWORD dwAdditionalFlags);

static HANDLE WINAPI MyFindFirstFileExW(LPCWSTR lpFileName, FINDEX_INFO_LEVELS fInfoLevelId, LPVOID lpFindFileData, FINDEX_SEARCH_OPS fSearchOp, LPVOID lpSearchFilter, DWORD dwAdditionalFlags);

static HANDLE WINAPI MyFindFirstFileTransactedA(LPCSTR lpFileName, FINDEX_INFO_LEVELS fInfoLevelId, LPVOID lpFindFileData, FINDEX_SEARCH_OPS fSearchOp, LPVOID lpSearchFilter, DWORD dwAdditionalFlags, HANDLE hTransaction);

static HANDLE WINAPI MyFindFirstFileTransactedW(LPCWSTR lpFileName, FINDEX_INFO_LEVELS fInfoLevelId, LPVOID lpFindFileData, FINDEX_SEARCH_OPS fSearchOp, LPVOID lpSearchFilter, DWORD dwAdditionalFlags, HANDLE hTransaction);

static BOOL WINAPI MyFindNextFileA(HANDLE hFindFile, LPWIN32_FIND_DATAA lpFindFileData);

static BOOL WINAPI MyFindNextFileW(HANDLE hFindFile, LPWIN32_FIND_DATAW lpFindFileData);

static void CompareCreateFileA(HANDLE* h_File, LPCSTR lpFileName);

static void CompareCreateFileW(HANDLE* h_File, LPCWSTR lpFileName);

static void CompareFindFileA(HANDLE* h_File, LPCSTR lpFileName, LPWIN32_FIND_DATAA lpFindFileData);

static void CompareFindFileW(HANDLE* h_File, LPCWSTR lpFileName, LPWIN32_FIND_DATAW lpFindFileData);

static void FreeDirNameIdx(unsigned long long i);

static void FreeDirNameHdl(HANDLE hFindFile);

static void MultiDetourAttach(FARPROC** BeforeFunc, FARPROC* AfterFunc, unsigned char amount);

static void MultiDetourDetach(FARPROC** BeforeFunc, FARPROC* AfterFunc, unsigned char amount);

static bool OpenEventExit(DWORD ProcessID);

static bool PipeGetResult(struct PipeStruct* ToExchange, bool LastCall);

static bool PipeDataExchange(struct PipeStruct* ToExchange);

static HANDLE(*OldCreateFileA)(LPCSTR lpFileName, DWORD dwDesiredAccess, DWORD dwShareMode, LPSECURITY_ATTRIBUTES lpSecurityAttributes, DWORD dwCreationDisposition, DWORD dwFlagsAndAttributes, HANDLE hTemplateFile) = CreateFileA;

static HANDLE(*OldCreateFileW)(LPCWSTR lpFileName, DWORD dwDesiredAccess, DWORD dwShareMode, LPSECURITY_ATTRIBUTES lpSecurityAttributes, DWORD dwCreationDisposition, DWORD dwFlagsAndAttributes, HANDLE hTemplateFile) = CreateFileW;

static HANDLE(*OldCreateFile2)(LPCWSTR lpFileName, DWORD dwDesiredAccess, DWORD dwShareMode, DWORD dwCreationDisposition, LPCREATEFILE2_EXTENDED_PARAMETERS pCreateExParams) = CreateFile2;

static HANDLE(*OldCreateFileTransactedA)(LPCSTR lpFileName, DWORD dwDesiredAccess, DWORD dwShareMode, LPSECURITY_ATTRIBUTES lpSecurityAttributes, DWORD dwCreationDisposition, DWORD dwFlagsAndAttributes, HANDLE hTemplateFile, HANDLE hTransaction, PUSHORT pusMiniVersion, PVOID lpExtendedParameter) = CreateFileTransactedA;

static HANDLE(*OldCreateFileTransactedW)(LPCWSTR lpFileName, DWORD dwDesiredAccess, DWORD dwShareMode, LPSECURITY_ATTRIBUTES lpSecurityAttributes, DWORD dwCreationDisposition, DWORD dwFlagsAndAttributes, HANDLE hTemplateFile, HANDLE hTransaction, PUSHORT pusMiniVersion, PVOID lpExtendedParameter) = CreateFileTransactedW;

static HANDLE(*OldFindFirstFileA)(LPCSTR lpFileName, LPWIN32_FIND_DATAA lpFindFileData) = FindFirstFileA;

static HANDLE(*OldFindFirstFileW)(LPCWSTR lpFileName, LPWIN32_FIND_DATAW lpFindFileData) = FindFirstFileW;

static HANDLE(*OldFindFirstFileExA)(LPCSTR lpFileName, FINDEX_INFO_LEVELS fInfoLevelId, LPVOID lpFindFileData, FINDEX_SEARCH_OPS fSearchOp, LPVOID lpSearchFilter, DWORD dwAdditionalFlags) = FindFirstFileExA;

static HANDLE(*OldFindFirstFileExW)(LPCWSTR lpFileName, FINDEX_INFO_LEVELS fInfoLevelId, LPVOID lpFindFileData, FINDEX_SEARCH_OPS fSearchOp, LPVOID lpSearchFilter, DWORD dwAdditionalFlags) = FindFirstFileExW;

static HANDLE(*OldFindFirstFileTransactedA)(LPCSTR lpFileName, FINDEX_INFO_LEVELS fInfoLevelId, LPVOID lpFindFileData, FINDEX_SEARCH_OPS fSearchOp, LPVOID lpSearchFilter, DWORD dwAdditionalFlags, HANDLE hTransaction) = FindFirstFileTransactedA;

static HANDLE(*OldFindFirstFileTransactedW)(LPCWSTR lpFileName, FINDEX_INFO_LEVELS fInfoLevelId, LPVOID lpFindFileData, FINDEX_SEARCH_OPS fSearchOp, LPVOID lpSearchFilter, DWORD dwAdditionalFlags, HANDLE hTransaction) = FindFirstFileTransactedW;

static BOOL(*OldFindNextFileA)(HANDLE hFindFile, LPWIN32_FIND_DATAA lpFindFileData) = FindNextFileA;

static BOOL(*OldFindNextFileW)(HANDLE hFindFile, LPWIN32_FIND_DATAW lpFindFileData) = FindNextFileW;

static FARPROC* OldFunc[13] = { &(FARPROC&)OldCreateFileW, &(FARPROC&)OldCreateFileA, &(FARPROC&)OldCreateFile2, &(FARPROC&)OldCreateFileTransactedA, &(FARPROC&)OldCreateFileTransactedW, &(FARPROC&)OldFindFirstFileA, &(FARPROC&)OldFindFirstFileW, &(FARPROC&)OldFindFirstFileExA, &(FARPROC&)OldFindFirstFileExW, &(FARPROC&)OldFindFirstFileTransactedA, &(FARPROC&)OldFindFirstFileTransactedW, &(FARPROC&)OldFindNextFileA, &(FARPROC&)OldFindNextFileW };

static FARPROC NewFunc[13] = { (FARPROC)MyCreateFileW, (FARPROC)MyCreateFileA, (FARPROC)MyCreateFile2, (FARPROC)MyCreateFileTransactedA, (FARPROC)MyCreateFileTransactedW, (FARPROC)MyFindFirstFileA, (FARPROC)MyFindFirstFileW, (FARPROC)MyFindFirstFileExA, (FARPROC)MyFindFirstFileExW, (FARPROC)MyFindFirstFileTransactedA, (FARPROC)MyFindFirstFileTransactedW, (FARPROC)MyFindNextFileA, (FARPROC)MyFindNextFileW };

extern "C" FARPROC OldFuncAsm = NULL;

extern "C"
{
    void NewFuncAsm();
};

extern "C" void HelperFunc()
{
    ReleaseSemaphore(h_SemaphoreNotifier, 1, NULL);
}

static HANDLE WINAPI MyCreateFileA(LPCSTR lpFileName, DWORD dwDesiredAccess, DWORD dwShareMode, LPSECURITY_ATTRIBUTES lpSecurityAttributes, DWORD dwCreationDisposition, DWORD dwFlagsAndAttributes, HANDLE hTemplateFile)
{
    HANDLE h_File = OldCreateFileA(lpFileName, dwDesiredAccess, dwShareMode, lpSecurityAttributes, dwCreationDisposition, dwFlagsAndAttributes, hTemplateFile);

    CompareCreateFileA(&h_File, lpFileName);

    return h_File;
}

static HANDLE WINAPI MyCreateFileW(LPCWSTR lpFileName, DWORD dwDesiredAccess, DWORD dwShareMode, LPSECURITY_ATTRIBUTES lpSecurityAttributes, DWORD dwCreationDisposition, DWORD dwFlagsAndAttributes, HANDLE hTemplateFile)
{
    HANDLE h_File = OldCreateFileW(lpFileName, dwDesiredAccess, dwShareMode, lpSecurityAttributes, dwCreationDisposition, dwFlagsAndAttributes, hTemplateFile);

    CompareCreateFileW(&h_File, lpFileName);

    return h_File;
}

static HANDLE WINAPI MyCreateFile2(LPCWSTR lpFileName, DWORD dwDesiredAccess, DWORD dwShareMode, DWORD dwCreationDisposition, LPCREATEFILE2_EXTENDED_PARAMETERS pCreateExParams)
{
    HANDLE h_File = OldCreateFile2(lpFileName, dwDesiredAccess, dwShareMode, dwCreationDisposition, pCreateExParams);

    CompareCreateFileW(&h_File, lpFileName);

    return h_File;
}

static HANDLE WINAPI MyCreateFileTransactedA(LPCSTR lpFileName, DWORD dwDesiredAccess, DWORD dwShareMode, LPSECURITY_ATTRIBUTES lpSecurityAttributes, DWORD dwCreationDisposition, DWORD dwFlagsAndAttributes, HANDLE hTemplateFile, HANDLE hTransaction, PUSHORT pusMiniVersion, PVOID lpExtendedParameter)
{
    HANDLE h_File = OldCreateFileTransactedA(lpFileName, dwDesiredAccess, dwShareMode, lpSecurityAttributes, dwCreationDisposition, dwFlagsAndAttributes, hTemplateFile, hTransaction, pusMiniVersion, lpExtendedParameter);

    CompareCreateFileA(&h_File, lpFileName);

    return h_File;
}

static HANDLE WINAPI MyCreateFileTransactedW(LPCWSTR lpFileName, DWORD dwDesiredAccess, DWORD dwShareMode, LPSECURITY_ATTRIBUTES lpSecurityAttributes, DWORD dwCreationDisposition, DWORD dwFlagsAndAttributes, HANDLE hTemplateFile, HANDLE hTransaction, PUSHORT pusMiniVersion, PVOID lpExtendedParameter)
{
    HANDLE h_File = OldCreateFileTransactedW(lpFileName, dwDesiredAccess, dwShareMode, lpSecurityAttributes, dwCreationDisposition, dwFlagsAndAttributes, hTemplateFile, hTransaction, pusMiniVersion, lpExtendedParameter);

    CompareCreateFileW(&h_File, lpFileName);

    return h_File;
}

static HANDLE WINAPI MyFindFirstFileA(LPCSTR lpFileName, LPWIN32_FIND_DATAA lpFindFileData)
{
    HANDLE h_File = OldFindFirstFileA(lpFileName, lpFindFileData);

    CompareFindFileA(&h_File, lpFileName, lpFindFileData);

    return h_File;
}

static HANDLE WINAPI MyFindFirstFileW(LPCWSTR lpFileName, LPWIN32_FIND_DATAW lpFindFileData)
{
    HANDLE h_File = OldFindFirstFileW(lpFileName, lpFindFileData);

    CompareFindFileW(&h_File, lpFileName, lpFindFileData);

    return h_File;
}

static HANDLE WINAPI MyFindFirstFileExA(LPCSTR lpFileName, FINDEX_INFO_LEVELS fInfoLevelId, LPVOID lpFindFileData, FINDEX_SEARCH_OPS fSearchOp, LPVOID lpSearchFilter, DWORD dwAdditionalFlags)
{
    HANDLE h_File = OldFindFirstFileExA(lpFileName, fInfoLevelId, lpFindFileData, fSearchOp, lpSearchFilter, dwAdditionalFlags);

    CompareFindFileA(&h_File, lpFileName, (LPWIN32_FIND_DATAA)lpFindFileData);

    return h_File;
}

static HANDLE WINAPI MyFindFirstFileExW(LPCWSTR lpFileName, FINDEX_INFO_LEVELS fInfoLevelId, LPVOID lpFindFileData, FINDEX_SEARCH_OPS fSearchOp, LPVOID lpSearchFilter, DWORD dwAdditionalFlags)
{
    HANDLE h_File = OldFindFirstFileExW(lpFileName, fInfoLevelId, lpFindFileData, fSearchOp, lpSearchFilter, dwAdditionalFlags);

    CompareFindFileW(&h_File, lpFileName, (LPWIN32_FIND_DATAW)lpFindFileData);

    return h_File;
}

static HANDLE WINAPI MyFindFirstFileTransactedA(LPCSTR lpFileName, FINDEX_INFO_LEVELS fInfoLevelId, LPVOID lpFindFileData, FINDEX_SEARCH_OPS fSearchOp, LPVOID lpSearchFilter, DWORD dwAdditionalFlags, HANDLE hTransaction)
{
    HANDLE h_File = OldFindFirstFileTransactedA(lpFileName, fInfoLevelId, lpFindFileData, fSearchOp, lpSearchFilter, dwAdditionalFlags, hTransaction);

    CompareFindFileA(&h_File, lpFileName, (LPWIN32_FIND_DATAA)lpFindFileData);

    return h_File;
}

static HANDLE WINAPI MyFindFirstFileTransactedW(LPCWSTR lpFileName, FINDEX_INFO_LEVELS fInfoLevelId, LPVOID lpFindFileData, FINDEX_SEARCH_OPS fSearchOp, LPVOID lpSearchFilter, DWORD dwAdditionalFlags, HANDLE hTransaction)
{
    HANDLE h_File = OldFindFirstFileTransactedW(lpFileName, fInfoLevelId, lpFindFileData, fSearchOp, lpSearchFilter, dwAdditionalFlags, hTransaction);

    CompareFindFileW(&h_File, lpFileName, (LPWIN32_FIND_DATAW)lpFindFileData);

    return h_File;
}

static BOOL WINAPI MyFindNextFileA(HANDLE hFindFile, LPWIN32_FIND_DATAA lpFindFileData)
{
    BOOL flag = OldFindNextFileA(hFindFile, lpFindFileData);

    unsigned long long i;

    if (flag)
    {
        char RelNameA[MAX_PATH_OBJ + 1] = { 0 };

        char PassNameA[MAX_PATH_OBJ + 1] = { 0 };

        WaitForSingleObject(h_MutexSave, INFINITE);

        for (i = 0; i < SaveLimit; i++)
        {
            if (SaveDirInfo[i].h_File == hFindFile)
            {
                break;
            }
        }

        if (i != SaveLimit)
        {
            sprintf_s(RelNameA, (strlen(SaveDirInfo[i].DirNameA) + 1), "%s", SaveDirInfo[i].DirNameA);

            strcat_s(RelNameA, (MAX_PATH_OBJ + 1), lpFindFileData->cFileName);

            _fullpath(PassNameA, RelNameA, MAX_PATH_OBJ);

            if (!_stricmp(HideNameA, PassNameA))
            {
                FreeDirNameIdx(i);
                
                memset(lpFindFileData, 0, sizeof(WIN32_FIND_DATAA));

                flag = OldFindNextFileA(hFindFile, lpFindFileData);
            }
        }

        ReleaseMutex(h_MutexSave);
    }
    else if (ERROR_NO_MORE_FILES == GetLastError())
    {
        FreeDirNameHdl(hFindFile);
    }

    return flag;
}

static BOOL WINAPI MyFindNextFileW(HANDLE hFindFile, LPWIN32_FIND_DATAW lpFindFileData)
{
    BOOL flag = OldFindNextFileW(hFindFile, lpFindFileData);

    unsigned long long i;

    if (flag)
    {
        wchar_t RelNameW[MAX_PATH_OBJ + 1] = { 0 };

        wchar_t PassNameW[MAX_PATH_OBJ + 1] = { 0 };

        WaitForSingleObject(h_MutexSave, INFINITE);

        for (i = 0; i < SaveLimit; i++)
        {
            if (SaveDirInfo[i].h_File == hFindFile)
            {
                break;
            }
        }

        if (i != SaveLimit)
        {
            swprintf_s(RelNameW, (wcslen(SaveDirInfo[i].DirNameW) + 1), TEXT("%s"), SaveDirInfo[i].DirNameW);

            wcscat_s(RelNameW, (MAX_PATH_OBJ + 1), lpFindFileData->cFileName);

            _wfullpath(PassNameW, RelNameW, MAX_PATH_OBJ);

            if (!_wcsicmp(HideNameW, PassNameW))
            {
                FreeDirNameIdx(i);
                
                memset(lpFindFileData, 0, sizeof(WIN32_FIND_DATAW));

                flag = OldFindNextFileW(hFindFile, lpFindFileData);
            }
        }

        ReleaseMutex(h_MutexSave);
    }
    else if (ERROR_NO_MORE_FILES == GetLastError())
    {
        FreeDirNameHdl(hFindFile);
    }

    return flag;
}

static void CompareCreateFileA(HANDLE* h_File, LPCSTR lpFileName)
{
    if (INVALID_HANDLE_VALUE != *h_File && *h_File)
    {
        char PassNameA[MAX_PATH_OBJ + 1] = { 0 };

        _fullpath(PassNameA, lpFileName, MAX_PATH_OBJ);

        if (!_stricmp(HideNameA, PassNameA))
        {
            CloseHandle(*h_File);

            *h_File = INVALID_HANDLE_VALUE;
        }
    }
}

static void CompareCreateFileW(HANDLE* h_File, LPCWSTR lpFileName)
{
    if (INVALID_HANDLE_VALUE != *h_File && *h_File)
    {
        wchar_t PassNameW[MAX_PATH_OBJ + 1] = { 0 };

        _wfullpath(PassNameW, lpFileName, MAX_PATH_OBJ);

        if (!_wcsicmp(HideNameW, PassNameW))
        {
            CloseHandle(*h_File);

            *h_File = INVALID_HANDLE_VALUE;
        }
    }
}

static void CompareFindFileA(HANDLE* h_File, LPCSTR lpFileName, LPWIN32_FIND_DATAA lpFindFileData)
{
    if (INVALID_HANDLE_VALUE != *h_File && *h_File)
    {
        char PassNameA[MAX_PATH_OBJ + 1] = { 0 };

        _fullpath(PassNameA, lpFileName, MAX_PATH_OBJ);

        char* p = strrchr(PassNameA, '\\');

        if (p)
        {
            p[1] = '\0';

            bool flag = false;

            unsigned long long i;

            if (!_strnicmp(HideNameA, PassNameA, strlen(PassNameA)))
            {
                WaitForSingleObject(h_MutexSave, INFINITE);

                if (SaveAmount == SaveLimit)
                {
                    SaveLimit <<= 1;

                    struct DirName* temp = SaveDirInfo;

                    SaveDirInfo = (struct DirName*)realloc(SaveDirInfo, SaveLimit * sizeof(struct DirName));

                    if (!SaveDirInfo)
                    {
                        SaveDirInfo = temp;

                        SaveLimit >>= 1;
                    }
                    else
                    {
                        memset(&SaveDirInfo[SaveAmount], 0, SaveAmount * sizeof(struct DirName));
                    }
                }

                if (SaveAmount != SaveLimit)
                {
                    for (i = 0; i < SaveLimit; i++)
                    {
                        if (!SaveDirInfo[i].h_File)
                        {
                            break;
                        }
                    }

                    size_t len = strlen(PassNameA) + 1;

                    SaveDirInfo[i].DirNameA = (char*)calloc(len, sizeof(char));

                    if (SaveDirInfo[i].DirNameA)
                    {
                        SaveDirInfo[i].DirNameW = (wchar_t*)calloc(len, sizeof(wchar_t));

                        if (SaveDirInfo[i].DirNameW)
                        {
                            len--;

                            if (mbstowcs_s(&len, SaveDirInfo[i].DirNameW, (len + 1), PassNameA, len))
                            {
                                free(SaveDirInfo[i].DirNameA);

                                SaveDirInfo[i].DirNameA = NULL;

                                free(SaveDirInfo[i].DirNameW);

                                SaveDirInfo[i].DirNameW = NULL;
                            }
                            else
                            {
                                SaveDirInfo[i].h_File = *h_File;

                                sprintf_s(SaveDirInfo[i].DirNameA, (strlen(PassNameA) + 1), "%s", PassNameA);

                                SaveAmount++;

                                flag = true;
                            }
                        }
                        else
                        {
                            free(SaveDirInfo[i].DirNameA);
                        }
                    }
                }

                ReleaseMutex(h_MutexSave);
            }

            strcat_s(PassNameA, (MAX_PATH_OBJ + 1), lpFindFileData->cFileName);

            *(p + strlen(lpFindFileData->cFileName) + 1) = '\0';

            if (!_stricmp(HideNameA, PassNameA))
            {
                if (!OldFindNextFileA(*h_File, lpFindFileData))
                {
                    if (flag)
                    {
                        WaitForSingleObject(h_MutexSave, INFINITE);

                        FreeDirNameIdx(i);

                        ReleaseMutex(h_MutexSave);
                    }

                    FindClose(*h_File);

                    *h_File = INVALID_HANDLE_VALUE;

                    memset(lpFindFileData, 0, sizeof(WIN32_FIND_DATAA));
                }
            }
        }
    }
}

static void CompareFindFileW(HANDLE* h_File, LPCWSTR lpFileName, LPWIN32_FIND_DATAW lpFindFileData)
{
    if (INVALID_HANDLE_VALUE != *h_File && *h_File)
    {
        wchar_t PassNameW[MAX_PATH_OBJ + 1] = { 0 };

        _wfullpath(PassNameW, lpFileName, MAX_PATH_OBJ);

        wchar_t* p = wcsrchr(PassNameW, L'\\');

        if (p)
        {
            p[1] = L'\0';

            bool flag = false;

            unsigned long long i;

            if (!_wcsnicmp(HideNameW, PassNameW, wcslen(PassNameW)))
            {
                WaitForSingleObject(h_MutexSave, INFINITE);

                if (SaveAmount == SaveLimit)
                {
                    SaveLimit <<= 1;

                    struct DirName* temp = SaveDirInfo;

                    SaveDirInfo = (struct DirName*)realloc(SaveDirInfo, SaveLimit * sizeof(struct DirName));

                    if (!SaveDirInfo)
                    {
                        SaveDirInfo = temp;

                        SaveLimit >>= 1;
                    }
                    else
                    {
                        memset(&SaveDirInfo[SaveAmount], 0, SaveAmount * sizeof(struct DirName));
                    }
                }

                if (SaveAmount != SaveLimit)
                {
                    for (i = 0; i < SaveLimit; i++)
                    {
                        if (!SaveDirInfo[i].h_File)
                        {
                            break;
                        }
                    }

                    size_t len = wcslen(PassNameW) + 1;

                    SaveDirInfo[i].DirNameA = (char*)calloc(len, sizeof(char));

                    if (SaveDirInfo[i].DirNameA)
                    {
                        SaveDirInfo[i].DirNameW = (wchar_t*)calloc(len, sizeof(wchar_t));

                        if (SaveDirInfo[i].DirNameW)
                        {
                            swprintf_s(SaveDirInfo[i].DirNameW, len, TEXT("%s"), PassNameW);

                            len--;

                            if (wcstombs_s(&len, SaveDirInfo[i].DirNameA, (len + 1), PassNameW, len))
                            {
                                free(SaveDirInfo[i].DirNameA);

                                SaveDirInfo[i].DirNameA = NULL;

                                free(SaveDirInfo[i].DirNameW);

                                SaveDirInfo[i].DirNameW = NULL;
                            }
                            else
                            {
                                SaveDirInfo[i].h_File = *h_File;

                                SaveAmount++;

                                flag = true;
                            }
                        }
                        else
                        {
                            free(SaveDirInfo[i].DirNameA);
                        }
                    }
                }

                ReleaseMutex(h_MutexSave);
            }

            wcscat_s(PassNameW, (MAX_PATH_OBJ + 1), lpFindFileData->cFileName);

            *(p + wcslen(lpFindFileData->cFileName) + 1) = L'\0';

            if (!_wcsicmp(HideNameW, PassNameW))
            {
                if (!OldFindNextFileW(*h_File, lpFindFileData))
                {
                    if (flag)
                    {
                        WaitForSingleObject(h_MutexSave, INFINITE);

                        FreeDirNameIdx(i);

                        ReleaseMutex(h_MutexSave);
                    }

                    FindClose(*h_File);

                    *h_File = INVALID_HANDLE_VALUE;

                    memset(lpFindFileData, 0, sizeof(WIN32_FIND_DATAW));
                }
            }
        }
    }
}

static void FreeDirNameIdx(unsigned long long i)
{
    SaveDirInfo[i].h_File = NULL;

    free(SaveDirInfo[i].DirNameA);

    SaveDirInfo[i].DirNameA = NULL;

    free(SaveDirInfo[i].DirNameW);

    SaveDirInfo[i].DirNameW = NULL;

    SaveAmount--;
}

static void FreeDirNameHdl(HANDLE hFindFile)
{
    unsigned long long i;

    WaitForSingleObject(h_MutexSave, INFINITE);

    for (i = 0; i < SaveLimit; i++)
    {
        if (SaveDirInfo[i].h_File == hFindFile)
        {
            break;
        }
    }

    if (i != SaveLimit)
    {
        SaveDirInfo[i].h_File = NULL;

        free(SaveDirInfo[i].DirNameA);

        SaveDirInfo[i].DirNameA = NULL;

        free(SaveDirInfo[i].DirNameW);

        SaveDirInfo[i].DirNameW = NULL;

        SaveAmount--;
    }

    ReleaseMutex(h_MutexSave);
}

static void MultiDetourAttach(FARPROC** BeforeFunc, FARPROC* AfterFunc, unsigned char amount)
{
    DetourRestoreAfterWith();

    DetourTransactionBegin();

    DetourUpdateThread(GetCurrentThread());

    for (unsigned char i = 0; i < amount; i++)
    {
        DetourAttach(&(PVOID&)*BeforeFunc[i], AfterFunc[i]);
    }

    DetourTransactionCommit();
}

static void MultiDetourDetach(FARPROC** BeforeFunc, FARPROC* AfterFunc, unsigned char amount)
{
    DetourTransactionBegin();

    DetourUpdateThread(GetCurrentThread());

    for (unsigned char i = 0; i < amount; i++)
    {
        DetourDetach(&(PVOID&)*BeforeFunc[i], AfterFunc[i]);
    }

    DetourTransactionCommit();
}

static bool OpenEventExit(DWORD ProcessID)
{
    wchar_t EventExitName[32] = { 0 };

    swprintf_s(EventExitName, (sizeof(EventExitName) >> 1), TEXT("event_lab2_EventExit_%lu"), ProcessID);

    h_EventExit = OpenEvent(EVENT_ALL_ACCESS, FALSE, EventExitName);

    if (!h_EventExit)
    {
        return false;
    }

    return true;
}

static bool PipeGetResult(struct PipeStruct* ToExchange, bool LastCall)
{
    if (WAIT_OBJECT_0 != WaitForSingleObject(ToExchange->PipeOverlap->hEvent, 1000))
    {
        return false;
    }

    DWORD BytesTransferred;;

    if (!GetOverlappedResult(ToExchange->h_Pipe, ToExchange->PipeOverlap, &BytesTransferred, FALSE))
    {
        return false;
    }

    if (LastCall)
    {
        if ((ToExchange->PipeMode && !BytesTransferred) || (!ToExchange->PipeMode && ToExchange->PipeBufSize != BytesTransferred))
        {
            return false;
        }
    }

    return true;
}

static bool PipeDataExchange(struct PipeStruct* ToExchange)
{
    if (!PipeGetResult(ToExchange, false))
    {
        return false;
    }

    bool flag;

    DWORD BytesTransferred;

    if (ToExchange->PipeMode)
    {
        flag = ReadFile(ToExchange->h_Pipe, ToExchange->PipeBuf, ToExchange->PipeBufSize, &BytesTransferred, ToExchange->PipeOverlap);
    }
    else
    {
        flag = WriteFile(ToExchange->h_Pipe, ToExchange->PipeBuf, ToExchange->PipeBufSize, &BytesTransferred, ToExchange->PipeOverlap);
    }

    if (flag && ((ToExchange->PipeMode && BytesTransferred) || (!ToExchange->PipeMode && ToExchange->PipeBufSize == BytesTransferred)))
    {
        return true;
    }

    if (!flag && ERROR_IO_PENDING == GetLastError())
    {
        return PipeGetResult(ToExchange, true);
    }

    return false;
}

BOOL APIENTRY DllMain(HMODULE hModule, DWORD ul_reason_for_call, LPVOID lpReserved)
{
    if (DetourIsHelperProcess())
    {
        return TRUE;
    }

    if (ul_reason_for_call == DLL_PROCESS_ATTACH)
    {
        HANDLE h_EventSend = NULL;

        HANDLE h_PipeEvent = NULL;

        HANDLE h_Pipe = NULL;

        HANDLE h_Snapshot = NULL;

        __try
        {
            DWORD ProcessID = GetCurrentProcessId();

            wchar_t EventSendName[32] = { 0 };

            swprintf_s(EventSendName, (sizeof(EventSendName) >> 1), TEXT("event_lab2_EventSend_%lu"), ProcessID);

            h_EventSend = OpenEvent(EVENT_ALL_ACCESS, FALSE, EventSendName);

            if (!h_EventSend)
            {
                __leave;
            }

            h_PipeEvent = CreateEvent(NULL, TRUE, TRUE, NULL);

            if (!h_PipeEvent)
            {
                SetEvent(h_EventSend);

                __leave;
            }

            wchar_t PipeName[25] = { 0 };

            swprintf_s(PipeName, (sizeof(PipeName) >> 1), TEXT("\\\\.\\pipe\\lab2_%lu"), ProcessID);

            h_Pipe = CreateNamedPipe(PipeName, PIPE_ACCESS_DUPLEX | FILE_FLAG_OVERLAPPED, PIPE_TYPE_MESSAGE | PIPE_READMODE_MESSAGE | PIPE_WAIT, 1, (MAX_PATH_OBJ + 1 + 1) * sizeof(wchar_t), sizeof(wchar_t), 1000, NULL);

            if (INVALID_HANDLE_VALUE == h_Pipe)
            {
                SetEvent(h_EventSend);

                __leave;
            }

            OVERLAPPED PipeOverlap = { 0 };

            PipeOverlap.hEvent = h_PipeEvent;

            if (ConnectNamedPipe(h_Pipe, &PipeOverlap) || ERROR_IO_PENDING != GetLastError())
            {
                SetEvent(h_EventSend);

                __leave;
            }

            wchar_t buf[MAX_PATH_OBJ + 3] = { 0 };

            struct PipeStruct ToExchange = { h_Pipe , &PipeOverlap, buf, (sizeof(buf) - 2), true };

            SetEvent(h_EventSend);

            if (!PipeDataExchange(&ToExchange))
            {
                __leave;
            }

            size_t ReturnValue;

            char ProcName[MAX_PATH_OBJ + 1] = { 0 };

            if (wcstombs_s(&ReturnValue, ProcName, sizeof(ProcName), &buf[1], (sizeof(ProcName) - 1)))
            {
                __leave;
            }

            FARPROC** ArgsOldFunc;

            FARPROC* ArgsNewFunc;

            unsigned char amount;

            if (L'1' == buf[0])
            {
                // Grab a new snapshot of the process
                h_Snapshot = CreateToolhelp32Snapshot(TH32CS_SNAPMODULE, ProcessID);

                if (INVALID_HANDLE_VALUE == h_Snapshot)
                {
                    __leave;
                }

                // Get the HMODULE of the desired library
                MODULEENTRY32 ModuleEntry = { sizeof(ModuleEntry) };

                OldFuncAsm = NULL;

                BOOL b_MoreMods = Module32FirstW(h_Snapshot, &ModuleEntry);

                for (; b_MoreMods; b_MoreMods = Module32NextW(h_Snapshot, &ModuleEntry))
                {
                    OldFuncAsm = GetProcAddress(ModuleEntry.hModule, ProcName);

                    if (OldFuncAsm)
                    {
                        break;
                    }
                }

                if (!OldFuncAsm)
                {
                    __leave;
                }

                wchar_t SemaphoreNotifierName[44] = { 0 };

                swprintf_s(SemaphoreNotifierName, (sizeof(SemaphoreNotifierName) >> 1), TEXT("semaphore_lab2_SemaphoreNotifier_%lu"), ProcessID);

                h_SemaphoreNotifier = OpenSemaphore(SEMAPHORE_ALL_ACCESS, FALSE, SemaphoreNotifierName);

                if (!h_SemaphoreNotifier)
                {
                    __leave;
                }

                EjectFlag = 1;

                OldFunc[0] = &(FARPROC&)OldFuncAsm;

                NewFunc[0] = (FARPROC)NewFuncAsm;

                amount = 1;
            }
            else if (L'0' == buf[0])
            {
                SaveDirInfo = (struct DirName*)calloc(SaveLimit, sizeof(struct DirName));

                if (!SaveDirInfo)
                {
                    __leave;
                }

                h_MutexSave = CreateMutex(NULL, FALSE, NULL);

                if (!h_MutexSave)
                {
                    __leave;
                }

                if (!_wfullpath(HideNameW, &buf[1], MAX_PATH_OBJ))
                {
                    __leave;
                }

                if (!_fullpath(HideNameA, ProcName, MAX_PATH_OBJ))
                {
                    __leave;
                }

                EjectFlag = 0;

                amount = 13;
            }
            else
            {
                __leave;
            }

            ArgsOldFunc = OldFunc;

            ArgsNewFunc = NewFunc;

            if (!OpenEventExit(ProcessID))
            {
                EjectFlag = 2;

                __leave;
            }

            MultiDetourAttach(ArgsOldFunc, ArgsNewFunc, amount);

            wchar_t answer = 1;

            ToExchange.PipeBuf = &answer;

            ToExchange.PipeBufSize = sizeof(answer);

            ToExchange.PipeMode = false;

            if (!PipeDataExchange(&ToExchange))
            {
                MultiDetourDetach(ArgsOldFunc, ArgsNewFunc, amount);

                EjectFlag = 2;
            }
        }
        __finally // Now, we can clean everything up
        {
            if (2 == EjectFlag)
            {
                if (h_EventExit)
                {
                    CloseHandle(h_EventExit);

                    h_EventExit = NULL;
                }

                if (h_SemaphoreNotifier)
                {
                    CloseHandle(h_SemaphoreNotifier);

                    h_SemaphoreNotifier = NULL;
                }

                if (h_MutexSave)
                {
                    CloseHandle(h_MutexSave);

                    h_MutexSave = NULL;
                }

                if (SaveDirInfo)
                {
                    free(SaveDirInfo);

                    SaveDirInfo = NULL;
                }
            }

            if (INVALID_HANDLE_VALUE != h_Snapshot && h_Snapshot)
            {
                CloseHandle(h_Snapshot);

                h_Snapshot = NULL;
            }

            if (INVALID_HANDLE_VALUE != h_Pipe && h_Pipe)
            {
                DisconnectNamedPipe(h_Pipe);

                CloseHandle(h_Pipe);

                h_Pipe = NULL;
            }

            if (!h_PipeEvent)
            {
                CloseHandle(h_PipeEvent);

                h_PipeEvent = NULL;
            }

            if (!h_EventSend)
            {
                CloseHandle(h_EventSend);

                h_EventSend = NULL;
            }
        }
    }
    else if (ul_reason_for_call == DLL_PROCESS_DETACH)
    {
        if (2 > EjectFlag)
        {
            FARPROC** ArgsOldFunc;

            FARPROC* ArgsNewFunc;

            unsigned char amount;

            if (1 == EjectFlag)
            {
                OldFunc[0] = &(FARPROC&)OldFuncAsm;

                NewFunc[0] = (FARPROC)NewFuncAsm;

                amount = 1;
            }
            else
            {
                amount = 13;
            }

            ArgsOldFunc = OldFunc;

            ArgsNewFunc = NewFunc;

            MultiDetourDetach(ArgsOldFunc, ArgsNewFunc, amount);

            if (h_SemaphoreNotifier)
            {
                CloseHandle(h_SemaphoreNotifier);

                h_SemaphoreNotifier = NULL;
            }

            if (h_MutexSave)
            {
                CloseHandle(h_MutexSave);

                h_MutexSave = NULL;
            }

            if (SaveDirInfo)
            {
                for (unsigned long long i = 0; i < SaveLimit; i++)
                {
                    if (SaveDirInfo[i].h_File)
                    {
                        SaveDirInfo[i].h_File = NULL;

                        free(SaveDirInfo[i].DirNameA);

                        SaveDirInfo[i].DirNameA = NULL;

                        free(SaveDirInfo[i].DirNameW);

                        SaveDirInfo[i].DirNameW = NULL;
                    }
                }

                free(SaveDirInfo);

                SaveDirInfo = NULL;
            }

            if (h_EventExit)
            {
                SetEvent(h_EventExit);

                CloseHandle(h_EventExit);

                h_EventExit = NULL;
            }
        }
    }

    return TRUE;
}

