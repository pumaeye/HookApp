#pragma once

#include "main.h"


#define INJECT_DLL_NAME TEXT("lab2.dll")
#define MAX_PATH_OBJ 32767


struct InjectArgs
{
	HANDLE h_MutexWriter;

	DWORD ProcessID;

	wchar_t* data;

	wchar_t* DllName;
};

void InjectToProcesses(DWORD* ProcessID, DWORD amount, wchar_t* data, wchar_t* DllName);

DWORD WINAPI InjectDll(_In_ struct InjectArgs* ToInjector);

void EjectDll(struct InjectArgs* ToInjector);

void LogMsg(struct InjectArgs* ToInjector, HANDLE* SynObject, unsigned char SynAmount);