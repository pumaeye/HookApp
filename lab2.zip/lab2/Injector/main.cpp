#include "main.h"


int wmain(int argc, wchar_t* argv[], wchar_t* envp[])
{
	int status = -1;

	if (5 != argc)
	{
		wprintf_s(TEXT("[!] Error: invalid number of command line arguments\n"));

		return status;
	}

	DWORD amount;

	DWORD* ProcessID = NULL;

	HANDLE hFindFile = NULL;

	wchar_t* data = NULL;

	__try
	{
		if (!wcscmp(TEXT("-pid"), argv[1]))
		{
			amount = 1;

			ProcessID = (DWORD*)malloc(sizeof(DWORD));

			if (!ProcessID)
			{
				wprintf_s(TEXT("[!] Error: not enough memory\n"));

				__leave;
			}

			if (!IsDWORDNumber(argv[2], &ProcessID[0]))
			{
				wprintf_s(TEXT("[!] Error: \'%s\' isn\'t correct DWORD\n"), argv[2]);

				__leave;
			}
		}
		else if (!wcscmp(TEXT("-name"), argv[1]))
		{
			amount = 1024;

			ProcessID = (DWORD*)malloc(amount * sizeof(DWORD));

			if (!ProcessID)
			{
				wprintf_s(TEXT("[!] Error: not enough memory\n"));

				__leave;
			}

			if (!GetProcessIDs(argv[2], &ProcessID, &amount))
			{
				__leave;
			}

			if (!amount)
			{
				wprintf_s(TEXT("[*] Processes with name \'%s\' were\'nt found\n"), argv[2]);

				status = 0;

				__leave;
			}
		}
		else
		{
			wprintf_s(TEXT("[!] Error: invalid command line arguments\n"));

			__leave;
		}

		if (wcscmp(TEXT("-func"), argv[3]) && wcscmp(TEXT("-hide"), argv[3]))
		{
			wprintf_s(TEXT("[!] Error: invalid command line arguments\n"));

			__leave;
		}

		data = (wchar_t*)calloc((wcslen(argv[4]) + 2), sizeof(wchar_t));

		if (!data)
		{
			wprintf_s(TEXT("[!] Error: not enough memory\n"));

			__leave;
		}

		swprintf_s(data, (wcslen(argv[4]) + 2), TEXT("1%s"), argv[4]);

		if ((MAX_PATH_OBJ + 1) < wcslen(data))
		{
			wprintf_s(TEXT("[!] Error: invalid command line arguments\n"));

			__leave;
		}

		if (L'h' == argv[3][1])
		{
			data[0] = L'0';
		}

		wchar_t DllName[MAX_PATH_OBJ + 1] = { 0 };

		if (!_wfullpath(DllName, INJECT_DLL_NAME, MAX_PATH_OBJ))
		{
			wprintf_s(TEXT("[!] Error: failed to fet full path to Dll for injection\n"));

			__leave;
		}

		WIN32_FIND_DATA FindFileData;

		hFindFile = FindFirstFile(DllName, &FindFileData);

		if (INVALID_HANDLE_VALUE == hFindFile)
		{
			wprintf_s(TEXT("[!] Error: failed to find Dll for injection\n"));

			__leave;
		}

		InjectToProcesses(ProcessID, amount, data, DllName);

		status = 0;
	}
	__finally // Now, we can clean everything up
	{
		if (INVALID_HANDLE_VALUE != hFindFile && hFindFile)
		{
			FindClose(hFindFile);

			hFindFile = NULL;
		}

		if (data)
		{
			free(data);

			data = NULL;
		}

		if (ProcessID)
		{
			free(ProcessID);

			ProcessID = NULL;
		}
	}

	return status;
}