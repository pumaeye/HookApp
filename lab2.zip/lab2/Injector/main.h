#pragma once

#include <Windows.h>
#include <stdio.h>
#include <stdbool.h>
#include <psapi.h>
#include <tlhelp32.h>

#include "Init.h"
#include "Injection.h"