#pragma once

#include "main.h"


bool IsDWORDNumber(wchar_t* str, DWORD* num);

bool GetProcessIDs(wchar_t* str, DWORD** ProcessID, DWORD* amount);