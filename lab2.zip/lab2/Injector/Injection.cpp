#include "Injection.h"


void InjectToProcesses(DWORD* ProcessID, DWORD amount, wchar_t* data, wchar_t* DllName)
{
	HANDLE h_MutexWriter = NULL;

	struct InjectArgs* ToInjector = NULL;

	HANDLE* child = NULL;

	__try
	{
		h_MutexWriter = CreateMutex(NULL, FALSE, NULL);

		if (!h_MutexWriter)
		{
			wprintf_s(TEXT("[!] Error: failed to create mutex for output management\n"));

			__leave;
		}

		ToInjector = (struct InjectArgs*)calloc(amount, sizeof(struct InjectArgs));

		if (!ToInjector)
		{
			wprintf_s(TEXT("[!] Error: not enough memory\n"));

			__leave;
		}

		child = (HANDLE*)calloc(amount, sizeof(HANDLE));

		if (!child)
		{
			wprintf_s(TEXT("[!] Error: not enough memory\n"));

			__leave;
		}

		for (DWORD i = 0; i < amount; i++)
		{
			ToInjector[i].h_MutexWriter = h_MutexWriter;

			ToInjector[i].ProcessID = ProcessID[i];

			ToInjector[i].data = data;

			ToInjector[i].DllName = DllName;

			if (!(child[i] = CreateThread(NULL, NULL, (LPTHREAD_START_ROUTINE)InjectDll, &ToInjector[i], 0, NULL)))
			{
				WaitForSingleObject(h_MutexWriter, INFINITE);

				wprintf_s(TEXT("[*] Failed to create thread-manager for process with PID \'%lu\'\n"), ToInjector[i].ProcessID);

				ReleaseMutex(h_MutexWriter);

				amount = i;
			}
		}

		WaitForMultipleObjects(amount, child, TRUE, INFINITE);
	}
	__finally
	{
		if (child)
		{
			free(child);

			child = NULL;
		}

		if (ToInjector)
		{
			free(ToInjector);

			ToInjector = NULL;
		}

		if (h_MutexWriter)
		{
			CloseHandle(h_MutexWriter);

			h_MutexWriter = NULL;
		}
	}
}

DWORD WINAPI InjectDll(_In_ struct InjectArgs* ToInjector)
{
	HANDLE h_Process = NULL;

	LPVOID DllNameRemoteAddr = NULL;

	HANDLE h_EventSend = NULL;

	HANDLE h_SemaphoreNotifier = NULL;

	HANDLE h_EventExit = NULL;

	HANDLE h_Thread = NULL;

	HANDLE h_Pipe = NULL;

	__try
	{
		// Get a handle for the target process.
		h_Process = OpenProcess(PROCESS_QUERY_INFORMATION | PROCESS_CREATE_THREAD | PROCESS_VM_OPERATION | PROCESS_VM_WRITE, FALSE, ToInjector->ProcessID);

		if (!h_Process)
		{
			WaitForSingleObject(ToInjector->h_MutexWriter, INFINITE);

			wprintf_s(TEXT("[*] Failed to get handle of process with PID \'%lu\'\n"), ToInjector->ProcessID);

			ReleaseMutex(ToInjector->h_MutexWriter);

			__leave;
		}

		// Calculate the number of bytes needed for the DLL's pathname
		SIZE_T MemorySize = (1 + lstrlen(ToInjector->DllName)) * sizeof(wchar_t);

		if (!MemorySize)
		{
			WaitForSingleObject(ToInjector->h_MutexWriter, INFINITE);

			wprintf_s(TEXT("[*] Failed to allocate space for the Dll\'s pathname in the remote process with PID \'%lu\'\n"), ToInjector->ProcessID);

			ReleaseMutex(ToInjector->h_MutexWriter);

			__leave;
		}

		// Allocate space in the remote process for the pathname
		DllNameRemoteAddr = VirtualAllocEx(h_Process, NULL, MemorySize, MEM_COMMIT, PAGE_READWRITE);

		if (!DllNameRemoteAddr)
		{
			WaitForSingleObject(ToInjector->h_MutexWriter, INFINITE);

			wprintf_s(TEXT("[*] Failed to allocate space for the Dll\'s pathname in the remote process with PID \'%lu\'\n"), ToInjector->ProcessID);

			ReleaseMutex(ToInjector->h_MutexWriter);

			__leave;
		}

		// Copy the DLL's pathname to the remote process' address space
		if (!WriteProcessMemory(h_Process, DllNameRemoteAddr, ToInjector->DllName, MemorySize, NULL))
		{
			WaitForSingleObject(ToInjector->h_MutexWriter, INFINITE);

			wprintf_s(TEXT("[*] Failed to copy the Dll\'s pathname to address space of the remote process with PID \'%lu\'\n"), ToInjector->ProcessID);

			ReleaseMutex(ToInjector->h_MutexWriter);

			__leave;
		}

		// Get the real address of LoadLibraryW in Kernel32.dll
		PTHREAD_START_ROUTINE StartFunc = (PTHREAD_START_ROUTINE)GetProcAddress(GetModuleHandle(TEXT("Kernel32")), "LoadLibraryW");

		if (!StartFunc)
		{
			WaitForSingleObject(ToInjector->h_MutexWriter, INFINITE);

			wprintf_s(TEXT("[*] Failed to get the real address of LoadLibraryW in Kernel32.dll\n"));

			ReleaseMutex(ToInjector->h_MutexWriter);

			__leave;
		}

		wchar_t EventSendName[32] = { 0 };

		swprintf_s(EventSendName, (sizeof(EventSendName) >> 1), TEXT("event_lab2_EventSend_%lu"), ToInjector->ProcessID);

		h_EventSend = CreateEvent(NULL, FALSE, FALSE, EventSendName);

		if (!h_EventSend)
		{
			WaitForSingleObject(ToInjector->h_MutexWriter, INFINITE);

			wprintf_s(TEXT("[*] Failed to create send-event for process with PID \'%lu\'\n"), ToInjector->ProcessID);

			ReleaseMutex(ToInjector->h_MutexWriter);

			__leave;
		}

		if (L'1' == ToInjector->data[0])
		{
			wchar_t SemaphoreNotifierName[44] = { 0 };

			swprintf_s(SemaphoreNotifierName, (sizeof(SemaphoreNotifierName) >> 1), TEXT("semaphore_lab2_SemaphoreNotifier_%lu"), ToInjector->ProcessID);

			h_SemaphoreNotifier = CreateSemaphore(NULL, 0, ((ULONG)((LONG)-1) >> 1), SemaphoreNotifierName);

			if (!h_SemaphoreNotifier)
			{
				WaitForSingleObject(ToInjector->h_MutexWriter, INFINITE);

				wprintf_s(TEXT("[*] Failed to create log-semaphore for process with PID \'%lu\'\n"), ToInjector->ProcessID);

				ReleaseMutex(ToInjector->h_MutexWriter);

				__leave;
			}
		}

		wchar_t EventExitName[32] = { 0 };

		swprintf_s(EventExitName, (sizeof(EventExitName) >> 1), TEXT("event_lab2_EventExit_%lu"), ToInjector->ProcessID);

		h_EventExit = CreateEvent(NULL, TRUE, FALSE, EventExitName);

		if (!h_EventExit)
		{
			WaitForSingleObject(ToInjector->h_MutexWriter, INFINITE);

			wprintf_s(TEXT("[*] Failed to create exit-event for process with PID \'%lu\'\n"), ToInjector->ProcessID);

			ReleaseMutex(ToInjector->h_MutexWriter);

			__leave;
		}

		// Create a remote thread that calls LoadLibraryW(DLLPathname)
		h_Thread = CreateRemoteThread(h_Process, NULL, 0, StartFunc, DllNameRemoteAddr, 0, NULL);

		if (!h_Thread)
		{
			WaitForSingleObject(ToInjector->h_MutexWriter, INFINITE);

			wprintf_s(TEXT("[*] Failed to create a remote thread in the remote process with PID \'%lu\'\n"), ToInjector->ProcessID);

			ReleaseMutex(ToInjector->h_MutexWriter);

			__leave;
		}

		WaitForSingleObject(h_EventSend, INFINITE);

		wchar_t PipeName[25] = { 0 };

		swprintf_s(PipeName, (sizeof(PipeName) >> 1), TEXT("\\\\.\\pipe\\lab2_%lu"), ToInjector->ProcessID);

		h_Pipe = CreateFile(PipeName, GENERIC_WRITE | GENERIC_READ, 0, NULL, OPEN_EXISTING, 0, NULL);

		if (INVALID_HANDLE_VALUE == h_Pipe)
		{
			WaitForSingleObject(ToInjector->h_MutexWriter, INFINITE);

			wprintf_s(TEXT("[*] Failed to open pipe to the remote process with PID \'%lu\'\n"), ToInjector->ProcessID);

			ReleaseMutex(ToInjector->h_MutexWriter);

			EjectDll(ToInjector);

			__leave;
		}

		DWORD PipeMode = PIPE_READMODE_MESSAGE;

		if (!SetNamedPipeHandleState(h_Pipe, &PipeMode, NULL, NULL))
		{
			WaitForSingleObject(ToInjector->h_MutexWriter, INFINITE);

			wprintf_s(TEXT("[*] Failed to set mode of pipe to the remote process with PID \'%lu\'\n"), ToInjector->ProcessID);

			ReleaseMutex(ToInjector->h_MutexWriter);

			EjectDll(ToInjector);

			__leave;
		}

		DWORD BytesTransferred;

		if (!WriteFile(h_Pipe, ToInjector->data, (DWORD)((wcslen(ToInjector->data) + 1) * sizeof(wchar_t)), &BytesTransferred, NULL))
		{
			WaitForSingleObject(ToInjector->h_MutexWriter, INFINITE);

			wprintf_s(TEXT("[*] Failed to send data to the remote process with PID \'%lu\'\n"), ToInjector->ProcessID);

			ReleaseMutex(ToInjector->h_MutexWriter);

			EjectDll(ToInjector);

			__leave;
		}

		wchar_t answer = 0;

		if (!ReadFile(h_Pipe, &answer, (DWORD)sizeof(wchar_t), &BytesTransferred, NULL))
		{
			WaitForSingleObject(ToInjector->h_MutexWriter, INFINITE);

			wprintf_s(TEXT("[*] Failed to read data from the remote process with PID \'%lu\'\n"), ToInjector->ProcessID);

			ReleaseMutex(ToInjector->h_MutexWriter);

			EjectDll(ToInjector);

			__leave;
		}

		// Wait for the remote thread to terminate
		WaitForSingleObject(h_Thread, INFINITE);

		WaitForSingleObject(ToInjector->h_MutexWriter, INFINITE);

		if (1 == answer)
		{
			wprintf_s(TEXT("[*] \'%s\' was successfully injected to the remote process with PID \'%lu\'\n"), ToInjector->DllName, ToInjector->ProcessID);

			ReleaseMutex(ToInjector->h_MutexWriter);

			if (L'1' == ToInjector->data[0])
			{
				HANDLE SynObject[2] = { h_SemaphoreNotifier, h_EventExit };

				LogMsg(ToInjector, SynObject, 2);
			}
			else
			{
				HANDLE SynObject[1] = { h_EventExit };

				LogMsg(ToInjector, SynObject, 1);
			}
		}
		else
		{
			wprintf_s(TEXT("[*] \'%s\' wasn't injected with desired access to the remote process with PID \'%lu\'\n"), ToInjector->DllName, ToInjector->ProcessID);

			ReleaseMutex(ToInjector->h_MutexWriter);

			EjectDll(ToInjector);
		}
	}
	__finally // Now, we can clean everything up
	{
		if (INVALID_HANDLE_VALUE != h_Pipe && h_Pipe)
		{
			CloseHandle(h_Pipe);

			h_Pipe = NULL;
		}

		if (h_Thread)
		{
			CloseHandle(h_Thread);

			h_Thread = NULL;
		}

		if (h_EventExit)
		{
			CloseHandle(h_EventExit);

			h_EventExit = NULL;
		}

		if (h_SemaphoreNotifier)
		{
			CloseHandle(h_SemaphoreNotifier);

			h_SemaphoreNotifier = NULL;
		}

		if (h_EventSend)
		{
			CloseHandle(h_EventSend);

			h_EventSend = NULL;
		}

		// Free the remote memory that contained the DLL's pathname
		if (DllNameRemoteAddr)
		{
			VirtualFreeEx(h_Process, DllNameRemoteAddr, 0, MEM_RELEASE);

			DllNameRemoteAddr = NULL;
		}

		if (h_Process)
		{
			CloseHandle(h_Process);

			h_Process = NULL;
		}
	}

	return 0;
}

void EjectDll(struct InjectArgs* ToInjector)
{
	HANDLE h_Snapshot = NULL;

	HANDLE h_Process = NULL;

	HANDLE h_Thread = NULL;

	__try
	{
		// Grab a new snapshot of the process
		h_Snapshot = CreateToolhelp32Snapshot(TH32CS_SNAPMODULE, ToInjector->ProcessID);

		if (INVALID_HANDLE_VALUE == h_Snapshot)
		{
			WaitForSingleObject(ToInjector->h_MutexWriter, INFINITE);

			wprintf_s(TEXT("[*] Failed to get handle of snapshot of process with PID \'%lu\'\n"), ToInjector->ProcessID);

			ReleaseMutex(ToInjector->h_MutexWriter);

			__leave;
		}

		// Get the HMODULE of the desired library
		MODULEENTRY32 ModuleEntry = { sizeof(ModuleEntry) };

		BOOL b_Found = FALSE;

		BOOL b_MoreMods = Module32FirstW(h_Snapshot, &ModuleEntry);

		for (; b_MoreMods; b_MoreMods = Module32NextW(h_Snapshot, &ModuleEntry))
		{
			b_Found = (_wcsicmp(ModuleEntry.szModule, ToInjector->DllName) == 0) || (_wcsicmp(ModuleEntry.szExePath, ToInjector->DllName) == 0);

			if (b_Found)
			{
				break;
			}
		}

		if (!b_Found)
		{
			WaitForSingleObject(ToInjector->h_MutexWriter, INFINITE);

			wprintf_s(TEXT("[*] Failed to find module \'%s\' in address space of process with PID \'%lu\'\n"), ToInjector->DllName, ToInjector->ProcessID);

			ReleaseMutex(ToInjector->h_MutexWriter);

			__leave;
		}

		// Get a handle for the target process.
		h_Process = OpenProcess(PROCESS_QUERY_INFORMATION | PROCESS_CREATE_THREAD | PROCESS_VM_OPERATION, FALSE, ToInjector->ProcessID);

		if (!h_Process)
		{
			WaitForSingleObject(ToInjector->h_MutexWriter, INFINITE);

			wprintf_s(TEXT("[*] Failed to get handle of process with PID \'%lu\'\n"), ToInjector->ProcessID);

			ReleaseMutex(ToInjector->h_MutexWriter);

			__leave;
		}

		// Get the real address of FreeLibrary in Kernel32.dll
		PTHREAD_START_ROUTINE StartFunc = (PTHREAD_START_ROUTINE)GetProcAddress(GetModuleHandle(TEXT("Kernel32")), "FreeLibrary");

		if (!StartFunc)
		{
			WaitForSingleObject(ToInjector->h_MutexWriter, INFINITE);

			wprintf_s(TEXT("[*] Failed to get the real address of FreeLibrary in Kernel32.dll\n"));

			ReleaseMutex(ToInjector->h_MutexWriter);

			__leave;
		}

		// Create a remote thread that calls FreeLibrary()
		h_Thread = CreateRemoteThread(h_Process, NULL, 0, StartFunc, ModuleEntry.modBaseAddr, 0, NULL);

		if (!h_Thread)
		{
			WaitForSingleObject(ToInjector->h_MutexWriter, INFINITE);

			wprintf_s(TEXT("[*] Failed to create a remote thread in the remote process with PID \'%lu\'\n"), ToInjector->ProcessID);

			ReleaseMutex(ToInjector->h_MutexWriter);

			__leave; 
		}

		// Wait for the remote thread to terminate
		WaitForSingleObject(h_Thread, INFINITE);

		WaitForSingleObject(ToInjector->h_MutexWriter, INFINITE);

		wprintf_s(TEXT("[*] \'%s\' was successfully ejected from the remote process with PID \'%lu\'\n"), ToInjector->DllName, ToInjector->ProcessID);

		ReleaseMutex(ToInjector->h_MutexWriter);
	}
	__finally // Now we can clean everything up
	{
		if (h_Thread)
		{
			CloseHandle(h_Thread);

			h_Thread = NULL;
		}

		if (h_Process)
		{
			CloseHandle(h_Process);

			h_Process = NULL;
		}

		if (INVALID_HANDLE_VALUE != h_Snapshot && h_Snapshot)
		{
			CloseHandle(h_Snapshot);

			h_Snapshot = NULL;
		}
	}
}

void LogMsg(struct InjectArgs* ToInjector, HANDLE* SynObject, unsigned char SynAmount)
{
	DWORD idx;

	SYSTEMTIME LocalTime;

	while (true)
	{
		idx = WaitForMultipleObjects(SynAmount, SynObject, FALSE, INFINITE) - WAIT_OBJECT_0;

		if (idx >= SynAmount)
		{
			WaitForSingleObject(ToInjector->h_MutexWriter, INFINITE);

			wprintf_s(TEXT("[*] Failed to wait signals from the remote process with PID \'%lu\'\n"), ToInjector->ProcessID);

			ReleaseMutex(ToInjector->h_MutexWriter);

			return;
		}

		if ((SynAmount - 1) == idx)
		{
			WaitForSingleObject(ToInjector->h_MutexWriter, INFINITE);

			wprintf_s(TEXT("[*] \'%s\' was ejected from the remote process with PID \'%lu\'\n"), ToInjector->DllName, ToInjector->ProcessID);

			ReleaseMutex(ToInjector->h_MutexWriter);

			return;
		}

		GetLocalTime(&LocalTime);

		WaitForSingleObject(ToInjector->h_MutexWriter, INFINITE);

		wprintf_s(TEXT("[#] Time - \'%02hu:%02hu:%02hu:%03hu\' | PID - \'%lu\' | Hooked - \'%s\'\n"), LocalTime.wHour, LocalTime.wMinute, LocalTime.wSecond, LocalTime.wMilliseconds, ToInjector->ProcessID, &ToInjector->data[1]);

		ReleaseMutex(ToInjector->h_MutexWriter);
	}
}