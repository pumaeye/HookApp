#include "Init.h"


bool IsDWORDNumber(wchar_t* str, DWORD* num)
{
	size_t len = wcslen(str);

	if (!len || 10 < len)
	{
		return false;
	}

	if (L'0' == str[0] && 1 < len)
	{
		return false;
	}

	for (unsigned char i = 0; i < len; i++)
	{
		if (L'0' > str[i] || L'9' < str[i])
		{
			return false;
		}
	}

	__int64 BigNum = _wtoi64(str);

	if (((DWORD)-1) < BigNum)
	{
		return false;
	}

	*num = (DWORD)BigNum;

	return true;
}

bool GetProcessIDs(wchar_t* str, DWORD** ProcessID, DWORD* amount)
{
	HANDLE h_ProcessSnap = CreateToolhelp32Snapshot(TH32CS_SNAPPROCESS, 0);

	if (INVALID_HANDLE_VALUE == h_ProcessSnap)
	{
		wprintf_s(TEXT("[!] Error: failed to take snapshot of processes\n"));

		h_ProcessSnap = NULL;

		return false;
	}

	PROCESSENTRY32 ProcessEntry;

	ProcessEntry.dwSize = sizeof(PROCESSENTRY32);

	if (!Process32First(h_ProcessSnap, &ProcessEntry))
	{
		wprintf_s(TEXT("[!] Error: failed to retrieve information about the first process\n"));

		CloseHandle(h_ProcessSnap);

		h_ProcessSnap = NULL;

		return false;
	}

	DWORD i = 0;

	DWORD* p = NULL;

	do
	{
		if (!_wcsicmp(str, ProcessEntry.szExeFile))
		{
			if (i == *amount)
			{
				*amount <<= 1;

				p = *ProcessID;

				*ProcessID = (DWORD*)realloc(*ProcessID, *amount * sizeof(DWORD));

				if (!*ProcessID)
				{
					wprintf_s(TEXT("[!] Error: not enough memory\n"));

					free(p);

					p = NULL;

					CloseHandle(h_ProcessSnap);

					h_ProcessSnap = NULL;

					return false;
				}

				p = NULL;
			}

			*ProcessID[i] = ProcessEntry.th32ProcessID;

			i++;
		}

	} while (Process32Next(h_ProcessSnap, &ProcessEntry));

	CloseHandle(h_ProcessSnap);

	h_ProcessSnap = NULL;

	if (!i)
	{
		free(*ProcessID);

		*ProcessID = NULL;

		*amount = 0;
	}
	else if (i < *amount)
	{
		*amount = i;

		p = *ProcessID;

		*ProcessID = (DWORD*)realloc(*ProcessID, *amount * sizeof(DWORD));

		if (!*ProcessID)
		{
			wprintf_s(TEXT("[!] Error: not enough memory\n"));

			free(p);

			p = NULL;

			return false;
		}
	}

	return true;
}